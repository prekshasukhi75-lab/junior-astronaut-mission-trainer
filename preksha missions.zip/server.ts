import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  GoogleGenAI,
  ThinkingLevel,
  Type,
  type GenerateContentResponse,
} from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const MODEL_NAME = 'gemini-4-hydrogen';

const ALLOWED_IMAGE_HOSTS = new Set([
  'images-assets.nasa.gov',
  'images-api.nasa.gov',
]);

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function isAllowedNasaImageUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    return (
      parsed.protocol === 'https:' && ALLOWED_IMAGE_HOSTS.has(parsed.hostname)
    );
  } catch {
    return false;
  }
}

async function fetchImageAsBase64(imageUrl: string): Promise<{
  data: string;
  mimeType: string;
}> {
  if (!isAllowedNasaImageUrl(imageUrl)) {
    throw new Error('UNSUPPORTED_IMAGE_URL');
  }

  const response = await fetch(imageUrl, {
    signal: AbortSignal.timeout(15000),
    headers: {
      Accept: 'image/*',
    },
  });

  if (!response.ok) {
    throw new Error(`IMAGE_FETCH_FAILED_${response.status}`);
  }

  const contentType = response.headers.get('content-type') || 'image/jpeg';
  const mimeType = contentType.split(';')[0].trim().toLowerCase();
  if (!mimeType.startsWith('image/')) {
    throw new Error('INVALID_IMAGE_MIME_TYPE');
  }

  const arrayBuffer = await response.arrayBuffer();
  if (arrayBuffer.byteLength === 0 || arrayBuffer.byteLength > 15 * 1024 * 1024) {
    throw new Error('INVALID_IMAGE_SIZE');
  }

  return {
    data: Buffer.from(arrayBuffer).toString('base64'),
    mimeType,
  };
}

function clamp01(value: unknown): number {
  const num = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(num)) return 0;
  return Math.max(0, Math.min(1, num));
}

interface RawPoint {
  x?: unknown;
  y?: unknown;
}

interface RawComponent {
  id?: unknown;
  name?: unknown;
  simpleDescription?: unknown;
  scientificExplanation?: unknown;
  interestingFact?: unknown;
  confidence?: unknown;
  evidenceNote?: unknown;
  points?: unknown;
  suggestedQuestions?: unknown;
}

interface RawAnalysisPayload {
  subject?: unknown;
  isSuitableForComponentExploration?: unknown;
  unsuitableReason?: unknown;
  summary?: unknown;
  components?: unknown;
}

function sanitizeAnalysisPayload(raw: RawAnalysisPayload) {
  const subject =
    typeof raw.subject === 'string' && raw.subject.trim()
      ? raw.subject.trim()
      : 'NASA Space Image';
  const isSuitable = Boolean(raw.isSuitableForComponentExploration);
  const unsuitableReason =
    typeof raw.unsuitableReason === 'string' ? raw.unsuitableReason.trim() : '';
  const summary =
    typeof raw.summary === 'string' ? raw.summary.trim() : '';

  const rawComponents = Array.isArray(raw.components) ? raw.components : [];
  const components = rawComponents
    .map((item: RawComponent, index: number) => {
      const name = typeof item.name === 'string' ? item.name.trim() : '';
      const simpleDescription =
        typeof item.simpleDescription === 'string'
          ? item.simpleDescription.trim()
          : '';
      const scientificExplanation =
        typeof item.scientificExplanation === 'string'
          ? item.scientificExplanation.trim()
          : '';
      const interestingFact =
        typeof item.interestingFact === 'string'
          ? item.interestingFact.trim()
          : '';
      const evidenceNote =
        typeof item.evidenceNote === 'string' ? item.evidenceNote.trim() : '';

      const rawConfidence =
        typeof item.confidence === 'string'
          ? item.confidence.toLowerCase()
          : 'medium';
      const confidence =
        rawConfidence === 'high' ||
        rawConfidence === 'medium' ||
        rawConfidence === 'low'
          ? rawConfidence
          : 'medium';

      const rawPoints = Array.isArray(item.points) ? item.points : [];
      const numericPoints = rawPoints
        .map((pt: RawPoint) => ({
          x: Number(pt?.x),
          y: Number(pt?.y),
        }))
        .filter((pt) => Number.isFinite(pt.x) && Number.isFinite(pt.y));

      const maxCoord = numericPoints.reduce(
        (acc, pt) => Math.max(acc, pt.x, pt.y),
        0
      );
      const scale = maxCoord > 1.05 && maxCoord <= 1000 ? 1000 : 1;

      const points = numericPoints.map((pt) => ({
        x: clamp01(pt.x / scale),
        y: clamp01(pt.y / scale),
      }));

      const suggestedQuestions = Array.isArray(item.suggestedQuestions)
        ? item.suggestedQuestions
            .filter((q): q is string => typeof q === 'string' && q.trim().length > 0)
            .slice(0, 4)
        : [];

      if (!name || !simpleDescription || points.length < 3) {
        return null;
      }

      return {
        id:
          typeof item.id === 'string' && item.id.trim()
            ? item.id.trim()
            : `component-${index + 1}`,
        name,
        simpleDescription,
        scientificExplanation: scientificExplanation || simpleDescription,
        interestingFact:
          interestingFact ||
          'NASA scientists study features like this using space telescopes and robotic explorers.',
        confidence,
        evidenceNote:
          evidenceNote ||
          'Identified visually from the selected NASA image.',
        region: {
          type: 'polygon' as const,
          points,
        },
        suggestedQuestions:
          suggestedQuestions.length > 0
            ? suggestedQuestions
            : [
                'What is it made of?',
                'Why is it important?',
                'Tell me an interesting fact.',
              ],
      };
    })
    .filter((comp): comp is NonNullable<typeof comp> => comp !== null);

  return {
    subject,
    isSuitableForComponentExploration: isSuitable && components.length > 0,
    unsuitableReason:
      !isSuitable || components.length === 0
        ? unsuitableReason ||
          'This image does not have clearly distinguishable structural parts or labeled diagram regions to outline reliably.'
        : '',
    summary,
    components,
  };
}

function extractJsonObjectString(raw: string): string {
  const trimmed = raw.trim();
  const fenced = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  if (fenced?.[1]) {
    return fenced[1].trim();
  }
  const firstBrace = trimmed.indexOf('{');
  const lastBrace = trimmed.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    return trimmed.slice(firstBrace, lastBrace + 1);
  }
  return trimmed;
}

async function generateWithRetry(
  fn: () => Promise<GenerateContentResponse>,
  maxAttempts = 2
): Promise<GenerateContentResponse> {
  let lastErr: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      const msg = err instanceof Error ? err.message : String(err);
      const isNonRetryable =
        msg.includes('400') ||
        msg.includes('403') ||
        msg.includes('429') ||
        msg.includes('RESOURCE_EXHAUSTED') ||
        msg.includes('API_KEY_INVALID') ||
        msg.includes('PERMISSION_DENIED');
      if (isNonRetryable || attempt === maxAttempts) {
        throw err;
      }
      await new Promise((r) => setTimeout(r, 600 * attempt));
    }
  }
  throw lastErr;
}

function mapGeminiError(
  error: unknown,
  context: 'analyze' | 'chat' = 'analyze'
): { status: number; code: string; message: string } {
  const errMsg = error instanceof Error ? error.message : String(error);
  console.error('[Gemini API error]', errMsg);
  if (errMsg.includes('403') || errMsg.includes('PERMISSION_DENIED')) {
    return {
      status: 403,
      code: 'AI_PERMISSION_DENIED',
      message: 'Gemini API access was denied. Please check GEMINI_API_KEY in Settings > Secrets.',
    };
  }
  if (errMsg.includes('API_KEY_INVALID')) {
    return {
      status: 400,
      code: 'AI_INVALID_KEY',
      message: 'The configured GEMINI_API_KEY appears invalid. Please verify it in Settings > Secrets.',
    };
  }
  if (errMsg.includes('429') || errMsg.includes('RESOURCE_EXHAUSTED')) {
    return {
      status: 429,
      code: 'AI_RATE_LIMITED',
      message: 'The AI science assistant is busy right now. Please wait a moment and try again.',
    };
  }
  if (errMsg.includes('Timeout') || errMsg.includes('AbortError')) {
    return {
      status: 504,
      code: 'AI_TIMEOUT',
      message:
        context === 'chat'
          ? 'ASTRA took too long to respond. Please try asking again.'
          : 'The image analysis request timed out. Please try again or pick a smaller image.',
    };
  }
  return {
    status: 502,
    code: 'AI_SERVICE_ERROR',
    message:
      context === 'chat'
        ? 'ASTRA is temporarily unavailable right now. You can still read the discovered component information beside the image.'
        : 'Unable to complete AI image analysis right now. You can still inspect the NASA image details or pick another image.',
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/ai/status', (_req: Request, res: Response) => {
    res.json({
      configured: Boolean(process.env.GEMINI_API_KEY?.trim()),
      model: MODEL_NAME,
    });
  });

  app.post('/api/ai/analyze-image', async (req: Request, res: Response) => {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        code: 'AI_NOT_CONFIGURED',
        message:
          'Gemini AI vision service is not configured. Set GEMINI_API_KEY in Settings > Secrets to enable AI image analysis.',
      });
      return;
    }

    const { imageUrl, nasaId, title, description, keywords } = req.body ?? {};
    if (typeof imageUrl !== 'string' || !imageUrl.trim()) {
      res.status(400).json({
        code: 'MISSING_IMAGE_URL',
        message: 'A valid NASA image URL is required for analysis.',
      });
      return;
    }

    try {
      const { data: base64Image, mimeType } = await fetchImageAsBase64(imageUrl);

      const metadataContext = [
        `NASA ID: ${typeof nasaId === 'string' ? nasaId : 'Unknown'}`,
        `Title: ${typeof title === 'string' ? title : 'Untitled'}`,
        `NASA Description: ${
          typeof description === 'string' && description.trim()
            ? description.slice(0, 600)
            : 'No description provided'
        }`,
        `Keywords: ${
          Array.isArray(keywords) ? keywords.slice(0, 12).join(', ') : 'None'
        }`,
      ].join('\n');

      const response: GenerateContentResponse = await generateWithRetry(() =>
        ai.models.generateContent({
          model: MODEL_NAME,
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType,
                  data: base64Image,
                },
              },
              {
                text: `Analyze this NASA space image for a child aged 7-12 in Mission: Little Astronaut.\n\nOfficial NASA Metadata Context:\n${metadataContext}\n\nInstructions:\n1. Inspect ONLY what is actually visible in the attached image.\n2. If distinct objects, celestial bodies, spacecraft parts, planetary features, or labeled diagram regions are clearly visible, set isSuitableForComponentExploration to true, set unsuitableReason to "", and return 2 to 5 distinct components.\n3. For EACH component, provide 4 to 6 ordered polygon vertices (x from 0.0 left to 1.0 right, y from 0.0 top to 1.0 bottom) outlining the visible feature.\n4. Only set isSuitableForComponentExploration to false (with components: []) if the image is mostly text, completely blurry/uniform, or has no distinguishable visual regions.\n5. Distinguish clearly between directly visible evidence and scientific interpretation in evidenceNote.\n6. Keep all descriptions short, accurate, and easy for ages 7-12 to understand.`,
              },
            ],
          },
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            systemInstruction:
              'You are a careful space science educator and computer-vision analyzer for children aged 7-12. Never fabricate unseen objects, never invent random coordinates, and never claim an AI interpretation is an official NASA caption.',
            responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            required: [
              'subject',
              'isSuitableForComponentExploration',
              'unsuitableReason',
              'summary',
              'components',
            ],
            properties: {
              subject: {
                type: Type.STRING,
                description: 'Short clear title of the main subject visible in the image.',
              },
              isSuitableForComponentExploration: {
                type: Type.BOOLEAN,
                description:
                  'True when distinct visible components or labeled diagram regions can be reliably outlined.',
              },
              unsuitableReason: {
                type: Type.STRING,
                description:
                  'Empty string when suitable; otherwise a clear child-friendly explanation.',
              },
              summary: {
                type: Type.STRING,
                description: 'Short 2-sentence kid-friendly overview of what is visible.',
              },
              components: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  required: [
                    'id',
                    'name',
                    'simpleDescription',
                    'scientificExplanation',
                    'interestingFact',
                    'confidence',
                    'evidenceNote',
                    'points',
                    'suggestedQuestions',
                  ],
                  properties: {
                    id: { type: Type.STRING },
                    name: { type: Type.STRING },
                    simpleDescription: { type: Type.STRING },
                    scientificExplanation: { type: Type.STRING },
                    interestingFact: { type: Type.STRING },
                    confidence: {
                      type: Type.STRING,
                      description: 'Must be high, medium, or low.',
                    },
                    evidenceNote: {
                      type: Type.STRING,
                      description:
                        'What is directly visible versus inferred from astronomy knowledge.',
                    },
                    points: {
                      type: Type.ARRAY,
                      description:
                        'Ordered polygon vertices outlining the component in normalized 0..1 coordinates (minimum 4 vertices).',
                      items: {
                        type: Type.OBJECT,
                        required: ['x', 'y'],
                        properties: {
                          x: { type: Type.NUMBER },
                          y: { type: Type.NUMBER },
                        },
                      },
                    },
                    suggestedQuestions: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                  },
                },
              },
            },
          },
        },
        })
      );

      const rawText = (response.text ?? '').trim();
      if (!rawText) {
        res.status(502).json({
          code: 'EMPTY_AI_RESPONSE',
          message: 'The AI analyzer returned an empty response. Please try another image.',
        });
        return;
      }

      let parsed: RawAnalysisPayload;
      try {
        parsed = JSON.parse(extractJsonObjectString(rawText)) as RawAnalysisPayload;
      } catch {
        res.status(502).json({
          code: 'INVALID_AI_JSON',
          message: 'The AI response format could not be verified safely. Please try again.',
        });
        return;
      }

      const sanitized = sanitizeAnalysisPayload(parsed);
      res.json(sanitized);
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      if (
        msg.startsWith('UNSUPPORTED_IMAGE') ||
        msg.startsWith('IMAGE_FETCH_FAILED') ||
        msg.startsWith('INVALID_IMAGE')
      ) {
        res.status(400).json({
          code: 'IMAGE_FETCH_UNAVAILABLE',
          message:
            'Could not download this NASA image file for AI inspection. Please try another image.',
        });
        return;
      }
      const mapped = mapGeminiError(error);
      res.status(mapped.status).json({
        code: mapped.code,
        message: mapped.message,
      });
    }
  });

  app.post('/api/ai/astra-chat', async (req: Request, res: Response) => {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        code: 'AI_NOT_CONFIGURED',
        message:
          'ASTRA live chat requires GEMINI_API_KEY in Settings > Secrets. You can still read the discovered component information above.',
      });
      return;
    }

    const { question, imageContext, selectedComponent, history } = req.body ?? {};
    if (typeof question !== 'string' || !question.trim()) {
      res.status(400).json({
        code: 'EMPTY_QUESTION',
        message: 'Please ask ASTRA a space science question.',
      });
      return;
    }

    try {
      const safeHistory = Array.isArray(history)
        ? history
            .slice(-6)
            .map((entry: { role?: string; text?: string }) =>
              `${entry.role === 'user' ? 'Explorer' : 'ASTRA'}: ${String(
                entry.text || ''
              ).slice(0, 300)}`
            )
            .join('\n')
        : '';

      const prompt = [
        `NASA Image Context:`,
        `Title: ${String(imageContext?.title || 'NASA Image')}`,
        `NASA ID: ${String(imageContext?.nasaId || 'Unknown')}`,
        `NASA Description: ${String(imageContext?.description || 'None').slice(0, 500)}`,
        selectedComponent
          ? [
              `\nSelected Component:`,
              `Name: ${String(selectedComponent.name || '')}`,
              `Simple Description: ${String(selectedComponent.simpleDescription || '')}`,
              `Scientific Explanation: ${String(selectedComponent.scientificExplanation || '')}`,
              `Visible Evidence Note: ${String(selectedComponent.evidenceNote || '')}`,
            ].join('\n')
          : '',
        safeHistory ? `\nRecent Conversation:\n${safeHistory}` : '',
        `\nChild's Question: ${question.trim().slice(0, 400)}`,
      ]
        .filter(Boolean)
        .join('\n');

      const response: GenerateContentResponse = await generateWithRetry(() =>
        ai.models.generateContent({
          model: MODEL_NAME,
          contents: prompt,
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            systemInstruction:
              'You are ASTRA — Your Space Science Guide for children aged 7–12 inside Mission: Little Astronaut. Keep answers friendly, accurate, 2–4 short sentences, and exciting without being childish. Clearly distinguish scientific facts from uncertain interpretations. Never claim your answer is an official NASA caption.',
          },
        })
      );

      const answer = (response.text ?? '').trim();
      if (!answer) {
        res.status(502).json({
          code: 'EMPTY_ASTRA_RESPONSE',
          message: 'ASTRA could not generate an answer right now. Please try asking again.',
        });
        return;
      }

      res.json({ answer });
    } catch (error) {
      const mapped = mapGeminiError(error, 'chat');
      res.status(mapped.status).json({
        code: mapped.code,
        message: mapped.message,
      });
    }
  });

  // Cached server-side NASA APOD proxy (never exposes NASA_API_KEY to browser bundles)
  let cachedApod: {
    fetchedAt: number;
    data: {
      title: string;
      date: string;
      explanation: string;
      url: string;
      mediaType: string;
      copyright?: string;
      apodPageUrl: string;
    };
  } | null = null;

  app.get('/api/nasa/apod', async (_req: Request, res: Response) => {
    const now = Date.now();
    const hasCustomKey = Boolean(process.env.NASA_API_KEY?.trim());
    if (cachedApod && now - cachedApod.fetchedAt < 60 * 60 * 1000) {
      res.json({
        live: true,
        usingDemoKey: !hasCustomKey,
        item: cachedApod.data,
      });
      return;
    }

    const apiKey = process.env.NASA_API_KEY?.trim() || 'DEMO_KEY';
    try {
      const apodRes = await fetch(
        `https://api.nasa.gov/planetary/apod?api_key=${encodeURIComponent(apiKey)}&thumbs=true`,
        { signal: AbortSignal.timeout(10000) }
      );

      if (!apodRes.ok) {
        const status = apodRes.status;
        res.status(200).json({
          live: false,
          usingDemoKey: !hasCustomKey,
          code: status === 429 ? 'NASA_APOD_RATE_LIMITED' : `NASA_APOD_HTTP_${status}`,
          message:
            status === 429
              ? 'NASA APOD rate limit reached right now. Showing verified educational fallback content below.'
              : 'NASA APOD service is temporarily unavailable. Showing verified educational fallback content below.',
        });
        return;
      }

      const raw = (await apodRes.json()) as {
        title?: string;
        date?: string;
        explanation?: string;
        url?: string;
        thumbnail_url?: string;
        media_type?: string;
        copyright?: string;
      };

      const rawImgUrl =
        raw.media_type === 'video' ? raw.thumbnail_url || '' : raw.url || '';
      const safeUrl = rawImgUrl.replace(/^http:/, 'https:');
      const dateStr = raw.date || new Date().toISOString().slice(0, 10);
      const compactDate = dateStr.replaceAll('-', '').slice(2);

      const item = {
        title: raw.title?.trim() || 'NASA Astronomy Picture of the Day',
        date: dateStr,
        explanation: raw.explanation?.trim() || '',
        url: safeUrl,
        mediaType: raw.media_type || 'image',
        copyright: raw.copyright?.trim(),
        apodPageUrl: `https://apod.nasa.gov/apod/ap${compactDate}.html`,
      };

      cachedApod = { fetchedAt: now, data: item };
      res.json({
        live: true,
        usingDemoKey: !hasCustomKey,
        item,
      });
    } catch {
      res.status(200).json({
        live: false,
        usingDemoKey: !hasCustomKey,
        code: 'NASA_APOD_NETWORK_ERROR',
        message:
          'Could not connect to NASA APOD right now. Showing verified educational fallback content below.',
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);

    app.use('*', async (req: Request, res: Response) => {
      try {
        const fs = await import('node:fs/promises');
        const template = await fs.readFile(
          path.resolve(__dirname, 'index.html'),
          'utf-8'
        );
        const html = await vite.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
      } catch (err) {
        vite.ssrFixStacktrace(err as Error);
        res.status(500).end('Internal Server Error');
      }
    });
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Mission: Little Astronaut server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
